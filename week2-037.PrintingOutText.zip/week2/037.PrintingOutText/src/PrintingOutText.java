public class PrintingOutText {

    public static void printText() {
        // Write your code here
    }

    public static void main(String[] args) {
        printText();
    }
}
